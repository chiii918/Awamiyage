package websys2.bean;

import java.io.Serializable;
import java.sql.Date;
import java.sql.Timestamp;

public class Makers implements Serializable {

	private int makers_id;
	private String makers_name;
	private String makers_post;
	private String makers_address;
	private String makers_tel;
	private String makers_fax;
	private String makers_mail;
	private String makers_homepage;
	private String makers_netshop;
	private int makers_holiday1;
	private int makers_holiday2;
	private int makers_holiday3;
	private String makers_open;
	private String shop_name;
	private String makers_person;
	private Date makers_paper;
	private Timestamp register_time;
	private String register_person;
	private Timestamp update_time;
	private String update_person;
	private Timestamp delete_time;
	private String delete_person;
	private boolean makers_show;


	/**
	 * コンストラクタ
	 */
	public Makers() {

	}


	public int getMakers_id() {
		return makers_id;
	}
	public void setMakers_id(int makers_id) {
		this.makers_id = makers_id;
	}

	public String getMakers_name() {
		return makers_name;
	}
	public void setMakers_name(String makers_name) {
		this.makers_name = makers_name;
	}

	public String getMakers_post() {
		return makers_post;
	}
	public void setMakers_post(String makers_post) {
		this.makers_post = makers_post;
	}

	public String getMakers_address() {
		return makers_address;
	}
	public void setMakers_address(String makers_address) {
		this.makers_address = makers_address;
	}

	public String getMakers_tel() {
		return makers_tel;
	}
	public void setMakers_tel(String makers_tel) {
		this.makers_tel = makers_tel;
	}

	public String getMakers_fax() {
		return makers_fax;
	}
	public void setMakers_fax(String makers_fax) {
		this.makers_fax = makers_fax;
	}

	public String getMakers_mail() {
		return makers_mail;
	}
	public void setMakers_mail(String makers_mail) {
		this.makers_mail = makers_mail;
	}

	public String getMakers_homepage() {
		return makers_homepage;
	}
	public void setMakers_homepage(String makers_homepage) {
		this.makers_homepage = makers_homepage;
	}

	public String getMakers_netshop() {
		return makers_netshop;
	}
	public void setMakers_netshop(String makers_netshop) {
		this.makers_netshop = makers_netshop;
	}

	public int getMakers_holiday1() {
		return makers_holiday1;
	}
	public void setMakers_holiday1(int makers_holiday1) {
		this.makers_holiday1 = makers_holiday1;
	}

	public int getMakers_holiday2() {
		return makers_holiday2;
	}
	public void setMakers_holiday2(int makers_holiday2) {
		this.makers_holiday2 = makers_holiday2;
	}

	public int getMakers_holiday3() {
		return makers_holiday3;
	}
	public void setMakers_holiday3(int makers_holiday3) {
		this.makers_holiday3 = makers_holiday3;
	}

	public String getMakers_open() {
		return makers_open;
	}
	public void setMakers_open(String makers_open) {
		this.makers_open = makers_open;
	}

	public String getMakers_person() {
		return makers_person;
	}
	public void setMakers_person(String makers_person) {
		this.makers_person = makers_person;
	}

	public java.sql.Date getMakers_paper() {
		return makers_paper;
	}
	public void setMakers_paper(java.sql.Date makers_paper) {
		this.makers_paper = makers_paper;
	}

	public Timestamp getRegister_time() {
		return register_time;
	}
	public void setRegister_time(Timestamp register_time) {
		this.register_time = register_time;
	}

	public String getRegister_person() {
		return register_person;
	}
	public void setRegister_person(String register_person) {
		this.register_person = register_person;
	}

	public Timestamp getUpdate_time() {
		return update_time;
	}
	public void setUpdate_time(Timestamp update_time) {
		this.update_time = update_time;
	}

	public String getUpdate_person() {
		return update_person;
	}
	public void setUpdate_person(String update_person) {
		this.update_person = update_person;
	}

	public Timestamp getDelete_time() {
		return delete_time;
	}
	public void setDelete_time(Timestamp delete_time) {
		this.delete_time = delete_time;
	}

	public String getDelete_person() {
		return delete_person;
	}
	public void setDelete_person(String delete_person) {
		this.delete_person = delete_person;
	}

	public boolean isMakers_show() {
		return makers_show;
	}
	public void setMakers_show(boolean makers_show) {
		this.makers_show = makers_show;
	}


	public String getShop_name() {
		return shop_name;
	}
	public void setShop_name(String shop_name) {
		this.shop_name = shop_name;
	}

}
