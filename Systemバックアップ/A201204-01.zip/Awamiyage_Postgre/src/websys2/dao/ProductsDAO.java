package websys2.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

//import websys2.bean.Makers;
import websys2.bean.Products;

public class ProductsDAO {
	/* 一覧ページに商品情報を取得するメソッド */
	public List<Products> list() {
		//検索結果を保持するリストのインスタンスを生成する
		List<Products> list = new ArrayList();
		try {
			//データベース接続インスタンスを取得する
			Connection conn = null;
			conn = DAO.conn;
			if(conn == null) return null;

			//SELECT文を準備
			String sql = "SELECT * FROM products";

			//SQLを送信
			PreparedStatement pStmt = conn.prepareStatement(sql);

			//SELECTを実行し、結果を取得してResultSetのインスタンスに代入
			ResultSet rs = pStmt.executeQuery();

			//rs結果表に格納されたレコードを行ごとに取得して出力する
			while (rs.next()) {
				//Product Beanのインスタンスを生成する
				Products p = new Products();

				//productのデータを取得
				p.setProducts_id(rs.getInt("products_id"));			//Id
				p.setProducts_name(rs.getString("products_name"));

				//セッティング済のBeanをリストに追加する
				list.add(p);
			}

			pStmt.close();
			rs.close();

			//データベースの接続から切断する
			//			DAO.closeConnection(conn);

		} catch (SQLException e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
		}
		//検索結果を集めているlistを呼び出す先に返す
		return list;
	}

	/* 商品情報を取得するメソッド */
	public Products detail(int pd_id) {
		//検索結果を保持するリストのインスタンスを生成する
		Products p = new Products();

		try {
			//データベース接続インスタンスを取得する
			Connection conn = null;
			conn = DAO.conn;
			if(conn == null) return null;

			//SELECT文を準備
			String sql =
					"SELECT " +
					"products_id" +
					",products_name" +
					",products_price" +
					",products_quantity" +
					",products_quantityunit" +
					",products_materials" +
					",products_deadline" +
					",products_save" +
					",products_capacity" +
					",products_capacityunit" +
					",products.makers_id" +
					",products.categorys_id" +
					",products.subcategorys_id" +
					",products_area" +
					",products_taste" +
					",products_scene" +
					",products_star" +
					",products_text" +
					",products_eyecatch" +
					",products_photo2" +
					",products_photo3" +
					",products_photo4" +
					",products_photo5" +
					",products_local" +
					",products_recommend" +
					",products.register_time" +
					",products.register_person" +
					",products.update_time" +
					",products.update_person" +
					",products.delete_time" +
					",products.delete_person" +
					",products_show" +
					",makers_name" +
					",makers_homepage" +
					",categorys_name" +
					",subcategorys_name " +
					"FROM products " +
					"INNER JOIN makers ON products.makers_id=makers.makers_id " +
					"INNER JOIN categorys ON products.categorys_id=categorys.categorys_id " +
					"INNER JOIN subcategorys ON categorys.categorys_id=subcategorys.categorys_id WHERE products_id = " + pd_id;

			System.out.println(sql);

			//SQLを送信
			PreparedStatement pStmt = conn.prepareStatement(sql);

			//SELECTを実行し、結果を取得してResultSetのインスタンスに代入
			ResultSet rs = pStmt.executeQuery();

			System.out.println("1");

			//productのデータを取得
			while(rs.next()) {
				p.setProducts_id(rs.getInt("products_id"));
				p.setProducts_name(rs.getString("products_name"));
				p.setProducts_price(rs.getString("products_price"));
				p.setProducts_quantity(rs.getString("products_quantity"));
				p.setProducts_quantityunit(rs.getString("products_quantityunit"));
				p.setProducts_materials(rs.getString("products_materials"));
				p.setProducts_deadline(rs.getString("products_deadline"));
				p.setProducts_save(rs.getInt("products_save"));
				p.setProducts_capacity(rs.getInt("products_capacity"));
				p.setProducts_capacityunit(rs.getString("products_capacityunit"));
				p.setMakers_id(rs.getInt("makers_id"));
				p.setCategorys_id(rs.getInt("categorys_id"));
				p.setSubcategorys_id(rs.getInt("subcategorys_id"));
				p.setProducts_area(rs.getInt("products_area"));
				p.setProducts_taste(rs.getInt("products_taste"));
				p.setProducts_scene(rs.getInt("products_scene"));
				p.setProducts_star(rs.getFloat("products_star"));
				p.setProducts_text(rs.getString("products_text"));
				p.setProducts_eyecatch(rs.getString("products_eyecatch"));
				p.setProducts_photo2(rs.getString("products_photo2"));
				p.setProducts_photo3(rs.getString("products_photo3"));
				p.setProducts_photo4(rs.getString("products_photo4"));
				p.setProducts_photo5(rs.getString("products_photo5"));
				p.setProducts_local(rs.getBoolean("products_local"));
				p.setProducts_recommend(rs.getBoolean("products_recommend"));
				p.setRegister_time(rs.getTimestamp("register_time"));
				p.setRegister_person(rs.getString("register_person"));
				p.setUpdate_time(rs.getTimestamp("update_time"));
				p.setUpdate_person(rs.getString("update_person"));
				p.setDelete_time(rs.getTimestamp("delete_time"));
				p.setDelete_person(rs.getString("delete_person"));
				p.setProducts_show(rs.getBoolean("products_show"));

				p.setMakers_name(rs.getString("makers_name"));
				p.setCategorys_name(rs.getString("categorys_name"));
				p.setSubcategorys_name(rs.getString("subcategorys_name"));
			}
			pStmt.close();
			rs.close();

			//データベースの接続から切断する
			//DAO.closeConnection(conn);

		} catch (SQLException e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
		}
		//検索結果を集めているlistを呼び出す先に返す
		return p;
	}

}
