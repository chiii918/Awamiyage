package websys2.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import websys2.bean.Makers;

public class MakersDAO {
	/* Makersテーブルに商品を追加する */
	public int insert(Makers makers) {
		int count = 0;			//処理件数、0＝異常

		//データベースに接続、読み込み、出力
		try {
			//データベース接続インスタンスを取得する
			Connection conn = null;
			conn = DAO.conn;
			if(conn == null) return count;

			//自動的コミットを無効させる
			conn.setAutoCommit(false);

			//SELECT文を準備
			String sql = "";
			sql += "INSERT INTO makers ";
			sql += "( makers_name, makers_post, makers_address, makers_tel, makers_fax, "
					+ "makers_mail, makers_homepage, makers_netshop, makers_holiday1, makers_holiday2, "
					+ "makers_holiday3, makers_open, makers_person, makers_paper, register_time, "
					+ "register_person, makers_show ) ";
			sql += "VALUES( ?, ?, ?, ?, ?, "
					+ "?, ?, ?, ?, ?,"
					+ "?, ?, ?, ?, ?,"
					+ "?, ? )";

			//SQLを送信
			PreparedStatement pStmt = conn.prepareStatement(sql);

			//それぞれのプレースホルダにpriceをセットする
			pStmt.setString(1,makers.getMakers_name());
			pStmt.setString(2,makers.getMakers_post());
			pStmt.setString(3,makers.getMakers_address());
			pStmt.setString(4,makers.getMakers_tel());
			pStmt.setString(5,makers.getMakers_fax());

			pStmt.setString(6,makers.getMakers_mail());
			pStmt.setString(7,makers.getMakers_homepage());
			pStmt.setString(8,makers.getMakers_netshop());
			pStmt.setInt(9,makers.getMakers_holiday1());
			pStmt.setInt(10,makers.getMakers_holiday2());

			pStmt.setInt(11,makers.getMakers_holiday3());
			pStmt.setString(12,makers.getMakers_open());
			pStmt.setString(13,makers.getMakers_person());
			pStmt.setDate(14,makers.getMakers_paper());
			pStmt.setTimestamp(15,makers.getRegister_time());

			pStmt.setString(16,makers.getRegister_person());
			pStmt.setBoolean(17,makers.isMakers_show());


			//仮でSQL文を実行する
			count = pStmt.executeUpdate();

			System.out.println("count:" + count);

			//画面に出力
			if (count==1) {
				conn.commit();		//コミットする
				System.out.println(count + "つの商品を追加しました");
			}else {
				conn.rollback();	//ロールバック
				System.out.println("商品の登録は失敗しました");
			}

			pStmt.close();

			//データベースの接続から切断する
			//			DAO.closeConnection(conn);

		} catch (SQLException e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
			System.out.println("商品を追加するにエラー発生しました");
		}

		return count;
	}



	/* すべての商品情報を取得するメソッド */
	public List<Makers> all() {

		//検索結果を保持するリストのインスタンスを生成する
		List<Makers> list = new ArrayList();

		try {

			//データベース接続インスタンスを取得する
			Connection conn = null;
			conn = DAO.conn;
			if(conn == null) return null;

			//SELECT文を準備
			String sql = "SELECT * FROM makers";

			//SQLを送信
			PreparedStatement pStmt = conn.prepareStatement(sql);

			//SELECTを実行し、結果を取得してResultSetのインスタンスに代入
			ResultSet rs = pStmt.executeQuery();

			//rs結果表に格納されたレコードを行ごとに取得して出力する
			while (rs.next()) {

				//Product Beanのインスタンスを生成する
				Makers m = new Makers();

				//productのデータを取得
				m.setMakers_id(rs.getInt("makers_id"));			//Id
				m.setMakers_name(rs.getString("makers_name"));	//name

				//セッティング済のBeanをリストに追加する
				list.add(m);
			}

			pStmt.close();
			rs.close();

			//データベースの接続から切断する
			//			DAO.closeConnection(conn);

		} catch (SQLException e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
		}

		//検索結果を集めているlistを呼び出す先に返す
		return list;

	}

}
