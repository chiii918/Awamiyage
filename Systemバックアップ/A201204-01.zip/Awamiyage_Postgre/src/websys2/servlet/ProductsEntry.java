package websys2.servlet;

import java.io.IOException;
import java.sql.Timestamp;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import websys2.bean.Makers;
import websys2.dao.MakersDAO;

/**
 * Servlet implementation class Insert
 */
@WebServlet("/ProductsEntry")
public class ProductsEntry extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public ProductsEntry() {
		super();
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		//セッションを取得
//		HttpSession session = request.getSession();

		//ログイン状態の確認、
		//ログイン状態でなければ、ログイン画面に移動
//		LoginCheck.isLogin(session, request, response);

		int count = 0;		//登録処理した件数

		//入力データを取得する
		//商品名
		String products_name = "";
		if ((request.getParameter("products_name")!=null)){
			products_name = request.getParameter("products_name");
		}
		//商品価格
		String products_price = "";
		if ((request.getParameter("products_price")!=null)){
			products_price = request.getParameter("products_price");
		}
		//入数
		String products_quantity = "";
		if ((request.getParameter("products_quantity")!=null)){
			products_quantity = request.getParameter("products_quantity");
		}
		//入数単位
		String products_quantityunit = "";
		if ((request.getParameter("products_quantityunit")!=null)){
			products_quantityunit = request.getParameter("products_quantityunit");
		}
		//原材料
		String products_materials = "";
		if ((request.getParameter("products_materials")!=null)){
			products_materials = request.getParameter("products_materials");
		}
		//賞味期限
		String products_deadline = "";
		if ((request.getParameter("products_deadline")!=null)){
			products_deadline = request.getParameter("products_deadline");
		}
		//保存方法
		int products_save = 0;
		if ((request.getParameter("products_save")!=null)){
			products_save = Integer.parseInt(request.getParameter("products_save"));
		}
		//内容量
		String products_capacity = "";
		if ((request.getParameter("products_capacity")!=null)){
			products_capacity = request.getParameter("products_capacity");
		}
		//内容量単位
		String products_capacityunit = "";
		if ((request.getParameter("products_capacityunit")!=null)){
			products_capacityunit = request.getParameter("products_capacityunit");
		}
		//メーカー
		int makers_id = 0;
		if ((request.getParameter("makers_id")!=null)){
			makers_id = Integer.parseInt(request.getParameter("makers_id"));
		}
		//カテゴリ
		int categorys_id = 0;
		if ((request.getParameter("categorys_id")!=null)){
			categorys_id = Integer.parseInt(request.getParameter("categorys_id"));
		}
		//エリア（市町村）
		int products_area = 0;
		if ((request.getParameter("products_area")!=null)){
			products_area = Integer.parseInt(request.getParameter("products_area"));
		}
		//味
		int products_taste = 0;
		if ((request.getParameter("products_taste")!=null)){
			products_taste = Integer.parseInt(request.getParameter("products_taste"));
		}
		//シーン
		int products_scene = 0;
		if ((request.getParameter("products_scene")!=null)){
			products_scene = Integer.parseInt(request.getParameter("products_scene"));
		}
		//評価
		float products_star = 0;
		if ((request.getParameter("products_star")!=null)){
			products_star = Float.parseFloat(request.getParameter("products_star"));
		}
		//商品説明
		String products_text = "";
		if ((request.getParameter("products_text")!=null)){
			products_text = request.getParameter("products_text");
		}
		//アイキャッチ（商品写真1）
		String products_eyecatch = "";
		if ((request.getParameter("products_eyecatch")!=null)){
			products_eyecatch = request.getParameter("products_eyecatch");
		}
		//商品写真2
		String products_photo2 = "";
		if ((request.getParameter("products_photo2")!=null)){
			products_photo2 = request.getParameter("products_photo2");
		}
		//商品写真3
		String products_photo3 = "";
		if ((request.getParameter("products_photo3")!=null)){
			products_photo3 = request.getParameter("products_photo3");
		}
		//商品写真4
		String products_photo4 = "";
		if ((request.getParameter("products_photo4")!=null)){
			products_photo4 = request.getParameter("products_photo4");
		}
		//商品写真5
		String products_photo5 = "";
		if ((request.getParameter("products_photo5")!=null)){
			products_photo5 = request.getParameter("products_photo5");
		}
		//名産品
		boolean products_local = true;
		if ((request.getParameter("products_local")!=null)){
			String bool = request.getParameter("products_local");
			products_local = Boolean.valueOf(bool);
		}
		//推しみやげ
		boolean products_recommend = true;
		if ((request.getParameter("products_recommend")!=null)){
			String bool = request.getParameter("products_recommend");
			products_recommend = Boolean.valueOf(bool);
		}
		//表示/非表示
		boolean products_show = true;
		if ((request.getParameter("products_show")!=null)){
			String bool = request.getParameter("products_show");
			products_show = Boolean.valueOf(bool);
		}


		//入力時に自動で取得
		//入力時刻
	    //協定世界時のUTC 1970年1月1日深夜零時との差をミリ秒で取得
	    long millis = System.currentTimeMillis();
	    //ミリ秒を引数としてTimestampオブジェクトを作成
	    Timestamp register_time = new Timestamp(millis);

	    //入力ユーザー
	    String register_person = "testuser";


		//Makers Beanのオブジェクトを生成する
		Makers makers = new Makers();

		//Beanインスタンスに値を代入する
		makers.setMakers_name(makers_name);
		makers.setMakers_post(makers_post);
		makers.setMakers_address(makers_address);
		makers.setMakers_tel(makers_tel);
		makers.setMakers_fax(makers_fax);
		makers.setMakers_mail(makers_mail);
		makers.setMakers_homepage(makers_homepage);
		makers.setMakers_netshop(makers_netshop);
		makers.setMakers_holiday1(makers_holiday1);
		makers.setMakers_holiday2(makers_holiday2);
		makers.setMakers_holiday3(makers_holiday3);
		makers.setMakers_open(makers_open);
		makers.setMakers_person(makers_person);
		makers.setMakers_paper(makers_paper);
		makers.setRegister_time(register_time);
		makers.setRegister_person(register_person);
		makers.setMakers_show(makers_show);





		setProducts_name(products_name);
		setProducts_price(products_price);
		setProducts_quantity(products_quantity);
		setProducts_quantityunit(products_quantityunit);
		setProducts_materials(products_materials);
		setProducts_deadline(products_deadline);
		setProducts_save(products_save);
		setProducts_capacity(products_capacity);
		setProducts_capacityunit(products_capacityunit);
		setMakers_id(makers_id);
		setCategorys_id(categorys_id);
		setSubcategorys_id(subcategorys_id);
		setProducts_area(products_area);
		setProducts_taste(products_taste);
		setProducts_scene(products_scene);
		setProducts_star(products_star);
		setProducts_text(products_text);
		setProducts_eyecatch(products_eyecatch);
		setProducts_photo2(products_photo2);
		setProducts_photo3(products_photo3);
		setProducts_photo4(products_photo4);
		setProducts_photo5(products_photo5);
		setProducts_local(products_local);
		setProducts_recommend(products_recommend);
		setRegister_time(register_time);
		setRegister_person(register_person);
		setProducts_show(products_show);













		//データベースに商品を挿入する
		MakersDAO dao = new MakersDAO();
		count = dao.insert(makers);

		//画面に出力
		if (count == 1) {
			request.setAttribute("message", "1つの商品が追加されました");
		}else {
			request.setAttribute("message", "商品追加が失敗しました");
		}

		//メーカー一覧画面にフォワード
		request.getRequestDispatcher("PageControlBack?pg_id=516").forward(request, response);

	}
}



