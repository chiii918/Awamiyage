package websys2.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import websys2.bean.Products;
import websys2.dao.ProductsDAO;

/**
 * Servlet implementation class ProductsAll
 */
@WebServlet("/ProductDetail")
public class ProductsDetail extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public ProductsDetail() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		//データベースに接続、読み込み
		ProductsDAO dao = new ProductsDAO();

		//検索結果を保持するリストのインスタンスを生成する
		Products products_detail = new Products();

		int pd_id = (int)request.getAttribute("pd_id");

		//daoのallメソッドを呼び出して、検索結果を取得する
		products_detail = dao.detail(pd_id);

		//リクエストにBeanを加える
		request.setAttribute("products_detail", products_detail);

		//フォワード
		request.getRequestDispatcher("WEB-INF/jsp/back/product_detail.jsp").forward(request, response);

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
