package websys2.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import websys2.bean.Reports;

public class ReportsBackDAO {

	/* お得情報(back,news_list) */
	public List<Reports> news_list() {

		List<Reports> list = new ArrayList();

		try {

			Connection conn = null;
			conn = DAO.conn;
			if(conn == null) return null;

			String sql = "SELECT * FROM reports "
					+ "WHERE delete_time IS NULL AND delete_person IS NULL "
					+ "AND reports_type = 3 "
					+ "ORDER BY reports_id ASC";


			PreparedStatement pStmt = conn.prepareStatement(sql);

			ResultSet rs = pStmt.executeQuery();

			while (rs.next()) {
				Reports r = new Reports();

				r.setReports_id(rs.getInt("reports_id"));
				r.setReports_name(rs.getString("reports_name"));

				list.add(r);
			}

			pStmt.close();
			rs.close();

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return list;
	}

	/* 試食記事(back,report_list) */
	public List<Reports> report_list() {

		List<Reports> list = new ArrayList();

		try {

			Connection conn = null;
			conn = DAO.conn;
			if(conn == null) return null;

			String sql = "SELECT reports_id, reports_name FROM reports "
					+ "WHERE delete_time IS NULL AND delete_person IS NULL "
					+ "AND reports_type = 1 OR reports_type = 2 "
					+ "ORDER BY reports_id ASC";

			PreparedStatement pStmt = conn.prepareStatement(sql);

			ResultSet rs = pStmt.executeQuery();

			while (rs.next()) {
				Reports r = new Reports();

				r.setReports_id(rs.getInt("reports_id"));
				r.setReports_name(rs.getString("reports_name"));

				list.add(r);
			}

			pStmt.close();
			rs.close();

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return list;
	}

	/* 記事情報を取得するメソッド */
	public Reports detail(int rp_id) {
		//検索結果を保持するリストのインスタンスを生成する
		Reports r = new Reports();

		try {
			//データベース接続インスタンスを取得する
			Connection conn = null;
			conn = DAO.conn;
			if(conn == null) return null;

			//SELECT文を準備
			String sql = "SELECT * FROM reports "
//					+ "INNER JOIN products ON reports.products_id1 = products.products_id "
//					+ "INNER JOIN makers ON reports.makers_id = makers.makers_id "
					+ "WHERE reports.reports_id = ?";

			System.out.println(sql);

			//SQLを送信
			PreparedStatement pStmt = conn.prepareStatement(sql);

			//それぞれのプレースホルダに値をセットする
			pStmt.setInt(1,rp_id);

			//SELECTを実行し、結果を取得してResultSetのインスタンスに代入
			ResultSet rs = pStmt.executeQuery();
			System.out.println("rs "+rs);

			//productのデータを取得
			while(rs.next()) {
				r.setReports_id(rs.getInt("reports_id"));
				r.setReports_name(rs.getString("reports_name"));
				r.setReports_type(rs.getInt("reports_type"));
				r.setReports_content1(rs.getString("reports_content1"));
				r.setReports_content2(rs.getString("reports_content2"));
				r.setReports_content3(rs.getString("reports_content3"));
				r.setReports_content4(rs.getString("reports_content4"));
				r.setReports_eyecatch(rs.getString("reports_eyecatch"));
				r.setReports_photo2(rs.getString("reports_photo2"));
				r.setReports_photo3(rs.getString("reports_photo3"));
				r.setReports_heading1(rs.getString("reports_heading1"));
				r.setReports_heading2(rs.getString("reports_heading2"));
				r.setReports_heading3(rs.getString("reports_heading3"));
				r.setProducts_id1(rs.getInt("products_id1"));
				r.setProducts_id2(rs.getInt("products_id2"));
				r.setProducts_id3(rs.getInt("products_id3"));
				r.setProducts_id4(rs.getInt("products_id4"));
				r.setProducts_id5(rs.getInt("products_id5"));
				r.setMakers_id(rs.getInt("makers_id"));
				r.setRegister_time(rs.getTimestamp("register_time"));
				r.setRegister_person(rs.getString("register_person"));
				r.setUpdate_time(rs.getTimestamp("update_time"));
				r.setUpdate_person(rs.getString("update_person"));
				r.setDelete_time(rs.getTimestamp("delete_time"));
				r.setDelete_person(rs.getString("delete_person"));
				r.setReports_show(rs.getBoolean("reports_show"));

				r.setProducts_name1(rs.getString("products_name1"));
				r.setProducts_name2(rs.getString("products_name2"));
				r.setProducts_name3(rs.getString("products_name3"));
				r.setProducts_name4(rs.getString("products_name4"));
				r.setProducts_name5(rs.getString("products_name5"));
				r.setMakers_name(rs.getString("makers_name"));
			}
			pStmt.close();
			rs.close();

		} catch (SQLException e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
		}
		//検索結果を集めているlistを呼び出す先に返す
		return r;
	}
}
