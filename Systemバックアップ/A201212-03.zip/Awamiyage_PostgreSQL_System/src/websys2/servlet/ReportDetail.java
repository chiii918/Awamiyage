package websys2.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import websys2.bean.Reports;
import websys2.dao.ReportsBackDAO;

/**
 * Servlet implementation class ProductsAll
 */
@WebServlet("/ReportDetail")
public class ReportDetail extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public ReportDetail() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		//データベースに接続、読み込み
		ReportsBackDAO dao = new ReportsBackDAO();

		//検索結果を保持するリストのインスタンスを生成する
		Reports report_detail = new Reports();

		int rp_id = (int)request.getAttribute("rp_id");

		//daoのallメソッドを呼び出して、検索結果を取得する
		report_detail = dao.detail(rp_id);

		//リクエストにBeanを加える
		request.setAttribute("report_detail", report_detail);

		//フォワード
		request.getRequestDispatcher("WEB-INF/jsp/back/report_detail.jsp").forward(request, response);

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
