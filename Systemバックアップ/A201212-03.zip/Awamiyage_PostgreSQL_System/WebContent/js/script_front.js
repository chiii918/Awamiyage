"use strict";



//jQueryはじまり
$(document).ready(function() {

	/*************** （taste）検索画面でのradioボタンの値をチェックしてコントロールに送信 **************/
	$('input[name="taste"]').change(function() {
	    var value = $(this).val();
	    window.location.href = './PageControlFront?pg_id=116&fr_id=5&ct_id=' + value;
//	    alert(value);
	});

	/*************** （price）検索画面でのradioボタンの値をチェックしてコントロールに送信 **************/
	$('input[name="products_pricerange"]').change(function() {
	    var value = $(this).val();
	    window.location.href = './PageControlFront?pg_id=114&fr_id=1&ct_id=' + value;
//	    alert(value);
	});
	/*************** （category）検索画面でのradioボタンの値をチェックしてコントロールに送信 **************/
	$('input[name="category"]').change(function() {
	    var value = $(this).val();
	    window.location.href = './PageControlFront?pg_id=119&fr_id=7&ct_id=' + value;
//	    alert(value);
	});
	/*************** （scene）検索画面でのradioボタンの値をチェックしてコントロールに送信 **************/
	$('input[name="scene"]').change(function() {
	    var value = $(this).val();
	    window.location.href = './PageControlFront?pg_id=118&fr_id=6&ct_id=' + value;
//	    alert(value);
	});




} );//jQuery終わり

