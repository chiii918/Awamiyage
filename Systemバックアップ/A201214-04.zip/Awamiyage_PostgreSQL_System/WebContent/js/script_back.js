"use strict";


//---------------------------------------------------------------------------
function check_alert(fnc){
// 「OK」時の処理 ＋ 確認ダイアログの表示
    var str;

	if (fnc == 1) {
		str = '商品情報を登録します。よろしいですか？';
	} else if (fnc == 2) {
		str = '商品情報を編集します。よろしいですか？';
	} else if (fnc == 3) {
		str = '本当に削除してもよろしいですか？';
	}

	if (window.confirm(str)) {

		// fnc要素を見つける
		var ele = document.getElementById('fnc');

		// fnc要素の属性を設定する
		ele.setAttribute('value', fnc);

		return true;

// 「キャンセル」時の処理開始
	} else {
		//window.alert('キャンセルされました');
		return false;
	}
}

//---------------------------------------------------------------------------

//アイキャッチの登録有無チェック
function p_check(){
	var eyecatchList = document.getElementById("products_eyecatch").files;
	var eyecatch = "";
	eyecatch = eyecatchList[0].name;	//file要素が配列で返ってくるため[0]指定（入力は1ファイルだけだから）

	if(eyecatch!=""){
//		window.alert(eyecatch);
		document.getElementById("photo_check").value = "1" ;
	}else{
//		window.alert(eyecatch);
		document.getElementById("photo_check").value = "0" ;
	}
}



//jQueryはじまり
$(document).ready(function() {

	/*************** （taste）検索画面でのradioボタンの値チェック【Ajax】 **************/
//	$('input[name="taste"]').change(function() {
//	    var value = $(this).val();
////	    alert(value);
//
//	    $.ajax({
//	        url : 'TasteList',
//	        type : 'POST',
//	        data : {taste : value},
//			dataType : 'json',
//	        success : function(response) {
//	        	alert(response);
////	        	console.log(response.products_list.length);
//
//	        	//登録されている項目があるとき：親要素を空にしてから表示、ないとき：親要素内を空にする
//	        	if(response.products_list.length != 0){
////	        		$('product__inner').empty();
//					for (var i = 0; i < response.products_list.length; i++) {
//						$('product__inner')
//						    .append('<a href="./PageControlFront?pg_id=113&from=5&pd_id='
//						    + response.products_list[i].products_id+ '">'
//						    + response.products_list[i].products_name + '</a>');
//						$('product__inner').append('<img src="' + response.products_list[i].products_eyecatch + '" alt="写真1">');
//						$('product__inner').append('<p>' + response.products_list[i].categorys_name + '</p>');
//						if(response.products_list[i].products_taste == 1){
//							$('product__inner').append('<p>甘い</p>');
//						}else if(response.products_list[i].products_taste == 2){
//							$('product__inner').append('<p>しょっぱい</p>');
//						}else if(response.products_list[i].products_taste == 3){
//							$('product__inner').append('<p>辛い</p>');
//						}else{
//							$('product__inner').append('<p>その他</p>');
//						}
//					}
//	        	}else{
////	        		$('product__inner').empty();
//	        	}
//
//	        },
//	        error : function() {
//	          console.log('通信エラーです');
//	        }
//	      })
//
//	})



	/*************** 親プルダウンの選択に応じて子プルダウンの中身を変更 **************/
	var $children = $('.children');		//子要素を変数に格納
	var original = $children.html();	//後のイベントで、不要なoption要素を削除するため、オリジナルをとっておく

	//親要素を変更するとイベントが発生
	$('.parent').change(function() {

	  //選択された親要素のvalueを取得し変数に入れる
	  var val1 = $(this).val();

	  //削除された要素をもとに戻すため.html(original)を入れておく
	  $children.html(original).find('option').each(function() {
	    var val2 = $(this).data('val'); //data-valの値を取得
	    console.log(this);

	    //valueと異なるdata-valを持つ要素を削除
	    if (val1 != val2) {
	      $(this).remove();
	    }

	  });
	});


} );//jQuery終わり

