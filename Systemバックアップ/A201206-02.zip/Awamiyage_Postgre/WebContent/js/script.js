"use strict";

function check_alert() {
    // 「OK」時の処理 ＋ 確認ダイアログの表示
    var res = confirm("本当に削除してもよろしいですか？");
    if (res == true) {
         return true;
    }
    // 「キャンセル」時の処理開始
    else {
        window.alert('削除をキャンセルしました'); // 警告ダイアログを表示
        return false;
    }

}