package websys2.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import websys2.bean.Makers;
import websys2.bean.Products;
import websys2.dao.MakersDAO;
import websys2.dao.ProductsDAO;

/**
 * Servlet implementation class ProductsAll
 */
@WebServlet("/ProductEdit")
public class ProductEdit extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public ProductEdit() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		//商品取得
		//データベースに接続、読み込み
		ProductsDAO pdao = new ProductsDAO();
		//検索結果を保持するリストのインスタンスを生成する
		Products products_detail = new Products();
		int pd_id = (int)request.getAttribute("pd_id");
		//daoのdetailメソッドを呼び出して、検索結果を取得する
		products_detail = pdao.detail(pd_id);


		//データベースに接続、読み込み
		MakersDAO mdao = new MakersDAO();
		//検索結果を保持するリストのインスタンスを生成する
		List<Makers> makers_list = new ArrayList();
		//daoのlistメソッドを呼び出して、検索結果を取得する
		makers_list = mdao.list();


		//リクエストにBeanを加える
		request.setAttribute("products_detail", products_detail);
		request.setAttribute("makers_list", makers_list);

		//フォワード
		request.getRequestDispatcher("WEB-INF/jsp/back/product_edit.jsp").forward(request, response);

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
