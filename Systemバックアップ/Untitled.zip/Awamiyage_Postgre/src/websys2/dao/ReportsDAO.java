package websys2.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import websys2.bean.Reports;

public class ReportsDAO {

	/* お得情報一覧 */
	public List<Reports> news_list() {

		List<Reports> list = new ArrayList();

		try {

			Connection conn = null;
			conn = DAO.conn;
			if(conn == null) return null;

			String sql = "SELECT * FROM reports "
					+ "WHERE reports_show = true "
					+ "AND reports_type = 3 ";

			//			System.out.println(sql);

			PreparedStatement pStmt = conn.prepareStatement(sql);

			ResultSet rs = pStmt.executeQuery();

			while (rs.next()) {
				Reports r = new Reports();

				r.setRegister_time(rs.getTimestamp("register_time"));
				r.setReports_id(rs.getInt("reports_id"));
				r.setReports_name(rs.getString("reports_name"));

				list.add(r);
			}

			pStmt.close();
			rs.close();

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return list;
	}

	/* レビュー一覧 */
	public List<Reports> report_list() {

		List<Reports> list = new ArrayList();

		try {

			Connection conn = null;
			conn = DAO.conn;
			if(conn == null) return null;

			String sql = "SELECT * FROM reports "
					+ "WHERE reports_show = true "
					+ "AND reports_type = 1 "
					+ "OR reports_type = 2 ";

//						System.out.println(sql);

			PreparedStatement pStmt = conn.prepareStatement(sql);
			ResultSet rs = pStmt.executeQuery();

			while (rs.next()) {
				Reports r = new Reports();

				r.setReports_id(rs.getInt("reports_id"));
				r.setReports_name(rs.getString("reports_name"));
				r.setReports_content1(rs.getString("reports_content1"));
				r.setReports_eyecatch(rs.getString("reports_eyecatch"));

				list.add(r);
			}

			pStmt.close();
			rs.close();

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return list;
	}
}
