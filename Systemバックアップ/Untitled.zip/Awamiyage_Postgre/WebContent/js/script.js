"use strict";

//削除時の確認アラート
function check_alert() {
    // 「OK」時の処理 ＋ 確認ダイアログの表示
    var res = confirm("本当に削除してもよろしいですか？");
    if (res == true) {
         return true;
    }
    // 「キャンセル」時の処理開始
    else {
        window.alert('削除をキャンセルしました'); // 警告ダイアログを表示
        return false;
    }

}

//アイキャッチの登録有無チェック
function check_photo(){
	var eyecatchList = document.getElementById("products_eyecatch").files;
	var eyecatch = "";
	eyecatch = eyecatchList[0].name;	//file要素が配列で返ってくるため[0]指定（入力は1ファイルだけだから）

	if(eyecatch!=""){
		window.alert(eyecatch);
		document.getElementById("photo_check").value = "1" ;
	}else{
		document.getElementById("photo_check").value = "0" ;
	}
}



//jQueryはじまり
$(document).ready(function() {

	/*************** （taste）検索画面でのradioボタンの値チェック **************/
	$('input[name="taste"]').change(function() {
	    var value = $(this).val();
//	    alert(value);

	    $.ajax({
	        url : 'TasteList',
	        type : 'POST',
	        data : {taste : value},
			dataType : 'json',
	        success : function(response) {
//	        	alert(response);
//	        	console.log(response.products_list.length);

	        	//登録されている項目があるとき：親要素を空にしてから表示、ないとき：親要素内を空にする
	        	if(response.products_list.length != 0){
	        		$('div').empty();
					for (var i = 0; i < response.products_list.length; i++) {
//						$('div').append('<p>' + response.products_list[i].products_id + '</p>');
						$('div').append('<a href="./PageControlFront?pg_id=113&from=5&pd_id=' + response.products_list[i].products_id
								+ '">' + response.products_list[i].products_name + '</a>');
						$('div').append('<img src="' + response.products_list[i].products_eyecatch + '" alt="写真1">');
						$('div').append('<p>' + response.products_list[i].categorys_name + '</p>');
						if(response.products_list[i].products_taste == 1){
							$('div').append('<p>甘い</p>');
						}else if(response.products_list[i].products_taste == 2){
							$('div').append('<p>しょっぱい</p>');
						}else if(response.products_list[i].products_taste == 3){
							$('div').append('<p>辛い</p>');
						}else{
							$('div').append('<p>その他</p>');
						}
					}
	        	}else{
	        		$('div').empty();
	        	}

	        },
	        error : function() {
	          console.log('通信エラーです');
	        }
	      })

	})



	/*************** 親プルダウンの選択に応じて子プルダウンの中身を変更 **************/
	var $children = $('.children');		//子要素を変数に格納
	var original = $children.html();	//後のイベントで、不要なoption要素を削除するため、オリジナルをとっておく

	//親要素を変更するとイベントが発生
	$('.parent').change(function() {

	  //選択された親要素のvalueを取得し変数に入れる
	  var val1 = $(this).val();

	  //削除された要素をもとに戻すため.html(original)を入れておく
	  $children.html(original).find('option').each(function() {
	    var val2 = $(this).data('val'); //data-valの値を取得
	    console.log(this);

	    //valueと異なるdata-valを持つ要素を削除
	    if (val1 != val2) {
	      $(this).remove();
	    }

	  });
	});


} );//jQuery終わり

