package websys2.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import websys2.bean.Makers;

public class MakersDAO {
	/* Makersテーブルにメーカーを追加する */
	public int insert(Makers makers) {
		int count = 0;			//処理件数、0＝異常

		//データベースに接続、読み込み、出力
		try {
			//データベース接続インスタンスを取得する
			Connection conn = null;
			conn = DAO.conn;
			if(conn == null) return count;

			//自動的コミットを無効させる
			conn.setAutoCommit(false);

			//SELECT文を準備
			String sql = "";
			sql += "INSERT INTO makers ";
			sql += "( makers_name, makers_post, makers_address, makers_tel, makers_fax, "
					+ "makers_mail, makers_homepage, makers_netshop, makers_holiday1, makers_holiday2, "
					+ "makers_holiday3, makers_open, shop_name, makers_person, makers_paper, "
					+ "register_time, register_person, makers_show ) ";
			sql += "VALUES( ?, ?, ?, ?, ?, "
					+ "?, ?, ?, ?, ?,"
					+ "?, ?, ?, ?, ?,"
					+ "?, ?, ? )";

			//SQLを送信
			PreparedStatement pStmt = conn.prepareStatement(sql);

			//それぞれのプレースホルダにpriceをセットする
			pStmt.setString(1,makers.getMakers_name());
			pStmt.setString(2,makers.getMakers_post());
			pStmt.setString(3,makers.getMakers_address());
			pStmt.setString(4,makers.getMakers_tel());
			pStmt.setString(5,makers.getMakers_fax());

			pStmt.setString(6,makers.getMakers_mail());
			pStmt.setString(7,makers.getMakers_homepage());
			pStmt.setString(8,makers.getMakers_netshop());
			pStmt.setInt(9,makers.getMakers_holiday1());
			pStmt.setInt(10,makers.getMakers_holiday2());

			pStmt.setInt(11,makers.getMakers_holiday3());
			pStmt.setString(12,makers.getMakers_open());
			pStmt.setString(13,makers.getShop_name());
			pStmt.setString(14,makers.getMakers_person());
			pStmt.setDate(15,makers.getMakers_paper());

			pStmt.setTimestamp(16,makers.getRegister_time());
			pStmt.setString(17,makers.getRegister_person());
			pStmt.setBoolean(18,makers.isMakers_show());


			//仮でSQL文を実行する
			count = pStmt.executeUpdate();

			System.out.println("count:" + count);

			//画面に出力
			if (count==1) {
				conn.commit();		//コミットする
				System.out.println(count + "社のメーカーを追加しました");
			}else {
				conn.rollback();	//ロールバック
				System.out.println("メーカーの登録に失敗しました");
			}

			pStmt.close();

			//データベースの接続から切断する
			//			DAO.closeConnection(conn);

		} catch (SQLException e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
			System.out.println("メーカーの追加時にエラーが発生しました");
		}

		return count;
	}


	/* メーカー情報を更新する */
	public int update(Makers makers) {
		int count = 0;			//処理件数、0＝異常

		//データベースに接続、読み込み、出力
		try {
			//データベース接続インスタンスを取得する
			Connection conn = null;
			conn = DAO.conn;
			if(conn == null) return count;

			//自動的コミットを無効させる
			conn.setAutoCommit(false);

			//SELECT文を準備
			String sql = "";
			sql += "UPDATE makers SET ";
			sql += "makers_name = ?, ";
			sql += "makers_post = ?, ";
			sql += "makers_address = ?, ";
			sql += "makers_tel= ?, ";
			sql += "makers_fax = ?, ";
			sql += "makers_mail = ?, ";
			sql += "makers_homepage = ?, ";
			sql += "makers_netshop = ?, ";
			sql += "makers_holiday1 = ?, ";
			sql += "makers_holiday2 = ?, ";
			sql += "makers_holiday3 = ?, ";
			sql += "makers_open = ?, ";
			sql += "shop_name = ?, ";
			sql += "makers_person = ?, ";
			sql += "makers_paper = ?, ";
			sql += "update_time = ?, ";
			sql += "update_person = ?, ";
			sql += "makers_show = ? ";
			sql += "WHERE makers_id = ? ";

			System.out.println(sql);

			//SQLを送信
			PreparedStatement pStmt = conn.prepareStatement(sql);

			//それぞれのプレースホルダにpriceをセットする
			pStmt.setString(1,makers.getMakers_name());
			pStmt.setString(2,makers.getMakers_post());
			pStmt.setString(3,makers.getMakers_address());
			pStmt.setString(4,makers.getMakers_tel());
			pStmt.setString(5,makers.getMakers_fax());

			pStmt.setString(6,makers.getMakers_mail());
			pStmt.setString(7,makers.getMakers_homepage());
			pStmt.setString(8,makers.getMakers_netshop());
			pStmt.setInt(9,makers.getMakers_holiday1());
			pStmt.setInt(10,makers.getMakers_holiday2());

			pStmt.setInt(11,makers.getMakers_holiday3());
			pStmt.setString(12,makers.getMakers_open());
			pStmt.setString(13,makers.getShop_name());
			pStmt.setString(14,makers.getMakers_person());
			pStmt.setDate(15,makers.getMakers_paper());

			pStmt.setTimestamp(16,makers.getUpdate_time());
			pStmt.setString(17,makers.getUpdate_person());
			pStmt.setBoolean(18,makers.isMakers_show());
			pStmt.setInt(19,makers.getMakers_id());

			//仮でSQL文を実行する
			count = pStmt.executeUpdate();

			System.out.println("count:" + count);

			//画面に出力
			if (count==1) {
				conn.commit();		//コミットする
				System.out.println(count + "社のメーカーを更新しました");
			}else {
				conn.rollback();	//ロールバック
				System.out.println("メーカー情報の更新に失敗しました");
			}

			pStmt.close();

			//データベースの接続から切断する
			//			DAO.closeConnection(conn);

		} catch (SQLException e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
			System.out.println("メーカー情報の更新時にエラーが発生しました");
		}

		return count;
	}



	/* メーカー情報を削除する */
	public int delete(Makers makers) {
		int count = 0;			//処理件数、0＝異常

		//データベースに接続、読み込み、出力
		try {
			//データベース接続インスタンスを取得する
			Connection conn = null;
			conn = DAO.conn;
			if(conn == null) return count;

			//自動的コミットを無効させる
			conn.setAutoCommit(false);

			//SELECT文を準備
			String sql = "";
			sql += "UPDATE makers SET ";
			sql += "delete_time = ?, ";
			sql += "delete_person = ? ";
			sql += "WHERE makers_id = ? ";

			System.out.println(sql);

			//SQLを送信
			PreparedStatement pStmt = conn.prepareStatement(sql);

			//それぞれのプレースホルダにpriceをセットする
			pStmt.setTimestamp(1,makers.getDelete_time());
			pStmt.setString(2,makers.getDelete_person());
			pStmt.setInt(3,makers.getMakers_id());

			System.out.println(pStmt);

			//仮でSQL文を実行する
			count = pStmt.executeUpdate();

			System.out.println("count:" + count);

			//画面に出力
			if (count==1) {
				conn.commit();		//コミットする
				System.out.println(count + "社のメーカーを削除しました");
			}else {
				conn.rollback();	//ロールバック
				System.out.println("メーカー情報の削除に失敗しました");
			}

			pStmt.close();

			//データベースの接続から切断する
			//			DAO.closeConnection(conn);

		} catch (SQLException e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
			System.out.println("メーカー情報の削除時にエラーが発生しました");
		}

		return count;
	}



	/* すべての商品情報を取得するメソッド */
	public List<Makers> list() {
		//検索結果を保持するリストのインスタンスを生成する
		List<Makers> list = new ArrayList();

		try {

			//データベース接続インスタンスを取得する
			Connection conn = null;
			conn = DAO.conn;
			if(conn == null) return null;

			//SELECT文を準備
			String sql = "SELECT * FROM makers";

			//SQLを送信
			PreparedStatement pStmt = conn.prepareStatement(sql);

			//SELECTを実行し、結果を取得してResultSetのインスタンスに代入
			ResultSet rs = pStmt.executeQuery();

			//rs結果表に格納されたレコードを行ごとに取得して出力する
			while (rs.next()) {

				//Product Beanのインスタンスを生成する
				Makers m = new Makers();

				//productのデータを取得
				m.setMakers_id(rs.getInt("makers_id"));			//Id
				m.setMakers_name(rs.getString("makers_name"));	//name

				//セッティング済のBeanをリストに追加する
				list.add(m);
			}

			pStmt.close();
			rs.close();

			//データベースの接続から切断する
			//			DAO.closeConnection(conn);

		} catch (SQLException e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
		}

		//検索結果を集めているlistを呼び出す先に返す
		return list;
	}



	/* 商品情報を取得するメソッド */
	public Makers detail(int mk_id) {
		//検索結果を保持するリストのインスタンスを生成する
		Makers m = new Makers();

		try {
			//データベース接続インスタンスを取得する
			Connection conn = null;
			conn = DAO.conn;
			if(conn == null) return null;

			//SELECT文を準備
			String sql = "SELECT * FROM makers WHERE makers_id = " + mk_id;

			System.out.println(sql);

			//SQLを送信
			PreparedStatement pStmt = conn.prepareStatement(sql);

			//SELECTを実行し、結果を取得してResultSetのインスタンスに代入
			ResultSet rs = pStmt.executeQuery();

			//productのデータを取得
			while(rs.next()) {
				m.setMakers_id(rs.getInt("makers_id"));
				m.setMakers_name(rs.getString("makers_name"));
				m.setMakers_post(rs.getString("makers_post"));
				m.setMakers_address(rs.getString("makers_address"));
				m.setMakers_tel(rs.getString("makers_tel"));
				m.setMakers_fax(rs.getString("makers_fax"));
				m.setMakers_mail(rs.getString("makers_mail"));
				m.setMakers_homepage(rs.getString("makers_homepage"));
				m.setMakers_netshop(rs.getString("makers_netshop"));
				m.setMakers_holiday1(rs.getInt("makers_holiday1"));
				m.setMakers_holiday2(rs.getInt("makers_holiday2"));
				m.setMakers_holiday3(rs.getInt("makers_holiday3"));
				m.setMakers_open(rs.getString("makers_open"));
				m.setShop_name(rs.getString("shop_name"));
				m.setMakers_person(rs.getString("makers_person"));
				m.setMakers_paper(rs.getDate("makers_paper"));
				m.setRegister_time(rs.getTimestamp("register_time"));
				m.setRegister_person(rs.getString("register_person"));
				m.setUpdate_time(rs.getTimestamp("update_time"));
				m.setUpdate_person(rs.getString("update_person"));
				m.setDelete_time(rs.getTimestamp("delete_time"));
				m.setDelete_person(rs.getString("delete_person"));
				m.setMakers_show(rs.getBoolean("makers_show"));

			}
			pStmt.close();
			rs.close();

			//データベースの接続から切断する
			//DAO.closeConnection(conn);

		} catch (SQLException e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
		}
		//検索結果を集めているlistを呼び出す先に返す
		return m;
	}

}
