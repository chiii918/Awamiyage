package websys2.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import websys2.bean.Products;

public class SelectDAO {
	//全ての商品を表示（ただしランダムに）
	public List<Products> all() {

		List<Products> list = new ArrayList();

		try {

			Connection conn = null;
			conn = DAO.conn;
			if(conn == null) return null;

			String sql = "SELECT * FROM products "
					+ "INNER JOIN categorys ON products.categorys_id = categorys.categorys_id "
					+ "WHERE products_show = true "
					+ "ORDER BY RANDOM() limit 12";

			PreparedStatement pStmt = conn.prepareStatement(sql);

			ResultSet rs = pStmt.executeQuery();

			while (rs.next()) {
				Products p = new Products();

				p.setProducts_id(rs.getInt("products_id"));
				p.setProducts_name(rs.getString("products_name"));
				p.setCategorys_name(rs.getString("categorys_name"));
				p.setProducts_taste(rs.getInt("products_taste"));
				p.setProducts_eyecatch(rs.getString("products_eyecatch"));

				list.add(p);
			}

			pStmt.close();
			rs.close();

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return list;
	}



	/* 味 */
	public List<Products> taste(int taste) {

		List<Products> list = new ArrayList();

		try {

			Connection conn = null;
			conn = DAO.conn;
			if(conn == null) return null;

			String sql = "SELECT * FROM products "
					+ "INNER JOIN categorys ON products.categorys_id = categorys.categorys_id "
					+ "WHERE products_show = true "
					+ "WHERE products_taste = ?";

			PreparedStatement pStmt = conn.prepareStatement(sql);
			pStmt.setInt(1,taste);

			ResultSet rs = pStmt.executeQuery();

			while (rs.next()) {
				Products p = new Products();

				p.setProducts_id(rs.getInt("products_id"));
				p.setProducts_name(rs.getString("products_name"));
				p.setCategorys_name(rs.getString("categorys_name"));
				p.setProducts_taste(rs.getInt("products_taste"));
				p.setProducts_eyecatch(rs.getString("products_eyecatch"));
				p.setProducts_show(rs.getBoolean("products_show"));

				list.add(p);
			}

			pStmt.close();
			rs.close();

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return list;
	}

	/* 名産品 */
	public List<Products> local() {

		List<Products> list = new ArrayList();

		try {

			Connection conn = null;
			conn = DAO.conn;
			if(conn == null) return null;

			String sql = "SELECT * FROM products "
					+ "INNER JOIN categorys ON products.categorys_id = categorys.categorys_id "
					+ "WHERE products_show = true "
					+ "AND products_local = true;";

			//			System.out.println(sql);

			PreparedStatement pStmt = conn.prepareStatement(sql);

			ResultSet rs = pStmt.executeQuery();

			while (rs.next()) {
				Products p = new Products();

				System.out.println("in while");

				p.setProducts_id(rs.getInt("products_id"));
				p.setProducts_name(rs.getString("products_name"));
				p.setCategorys_name(rs.getString("categorys_name"));
				p.setProducts_taste(rs.getInt("products_taste"));
				p.setProducts_eyecatch(rs.getString("products_eyecatch"));
				p.setProducts_show(rs.getBoolean("products_show"));

				list.add(p);
			}

			pStmt.close();
			rs.close();

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return list;
	}



	/* 推しみやげ */
	public List<Products> recommend() {

		List<Products> list = new ArrayList();

		try {

			Connection conn = null;
			conn = DAO.conn;
			if(conn == null) return null;

			String sql = "SELECT * FROM products "
					+ "INNER JOIN categorys ON products.categorys_id = categorys.categorys_id "
					+ "WHERE products_show = true "
					+ "AND products_recommend = true;";

			PreparedStatement pStmt = conn.prepareStatement(sql);

			ResultSet rs = pStmt.executeQuery();

			while (rs.next()) {
				Products p = new Products();

				p.setProducts_id(rs.getInt("products_id"));
				p.setProducts_name(rs.getString("products_name"));
				p.setCategorys_name(rs.getString("categorys_name"));
				p.setProducts_taste(rs.getInt("products_taste"));
				p.setProducts_eyecatch(rs.getString("products_eyecatch"));
				p.setProducts_show(rs.getBoolean("products_show"));

				list.add(p);
			}

			pStmt.close();
			rs.close();

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return list;
	}



	/* 価格別 */
	public List<Products> price(int price) {

		List<Products> list = new ArrayList();

		try {

			Connection conn = null;
			conn = DAO.conn;
			if(conn == null) return null;

			String sql = "SELECT products_id, products_price FROM products "
					+ "INNER JOIN categorys ON products.categorys_id = categorys.categorys_id "
					+ "WHERE products_show = true "
					+ "AND products_recommend = true "
					+ "AND products_pricerange = ?;";

			PreparedStatement pStmt = conn.prepareStatement(sql);
			pStmt.setInt(1,price);
			ResultSet rs = pStmt.executeQuery();

			while (rs.next()) {
				Products p = new Products();

				p.setProducts_id(rs.getInt("products_id"));
				p.setProducts_name(rs.getString("products_name"));
				p.setCategorys_name(rs.getString("categorys_name"));
				p.setProducts_taste(rs.getInt("products_taste"));
				p.setProducts_eyecatch(rs.getString("products_eyecatch"));
				p.setProducts_show(rs.getBoolean("products_show"));

				list.add(p);
			}

			pStmt.close();
			rs.close();

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return list;
	}



	/* 個数別 */
	public List<Products> quantity(int quantity) {

		List<Products> list = new ArrayList();

		try {

			Connection conn = null;
			conn = DAO.conn;
			if(conn == null) return null;

			String sql = "SELECT products_id, products_price FROM products "
					+ "INNER JOIN categorys ON products.categorys_id = categorys.categorys_id "
					+ "WHERE products_show = true "
					+ "AND products_recommend = true "
					+ "AND numbers LIKE '?,%' OR numbers LIKE '%,?,%' OR numbers LIKE '%,?';";

			PreparedStatement pStmt = conn.prepareStatement(sql);
			pStmt.setInt(1,quantity);
			pStmt.setInt(2,quantity);
			pStmt.setInt(3,quantity);
			ResultSet rs = pStmt.executeQuery();

			while (rs.next()) {
				Products p = new Products();

				p.setProducts_id(rs.getInt("products_id"));
				p.setProducts_name(rs.getString("products_name"));
				p.setCategorys_name(rs.getString("categorys_name"));
				p.setProducts_taste(rs.getInt("products_taste"));
				p.setProducts_eyecatch(rs.getString("products_eyecatch"));
				p.setProducts_show(rs.getBoolean("products_show"));

				list.add(p);
			}

			pStmt.close();
			rs.close();

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return list;
	}



}
