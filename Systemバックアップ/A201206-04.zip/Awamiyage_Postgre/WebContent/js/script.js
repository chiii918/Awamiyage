"use strict";

//削除時の確認アラート
function check_alert() {
    // 「OK」時の処理 ＋ 確認ダイアログの表示
    var res = confirm("本当に削除してもよろしいですか？");
    if (res == true) {
         return true;
    }
    // 「キャンセル」時の処理開始
    else {
        window.alert('削除をキャンセルしました'); // 警告ダイアログを表示
        return false;
    }

}


//jQueryはじまり
jQuery(function($){

	//親プルダウンの選択に応じて子プルダウンの中身を変更
	var $children = $('.children');		//子要素を変数に格納
	var original = $children.html();	//後のイベントで、不要なoption要素を削除するため、オリジナルをとっておく

	//親要素を変更するとイベントが発生
	$('.parent').change(function() {

	  //選択された親要素のvalueを取得し変数に入れる
	  var val1 = $(this).val();

	  //削除された要素をもとに戻すため.html(original)を入れておく
	  $children.html(original).find('option').each(function() {
	    var val2 = $(this).data('val'); //data-valの値を取得

	    //valueと異なるdata-valを持つ要素を削除
	    if (val1 != val2) {
	      $(this).remove();
	    }

	  });

	});


} );//jQuery終わり

