package websys2.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class PageControl
 */
@WebServlet("/PageControl")
public class PageControlFront extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public PageControlFront() {
		super();
		// TODO Auto-generated constructor stub
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		//リクエストパラメータを取得する
		//ページ番号
		String para1 = request.getParameter("pg_id");

		String forward = "";
		int pg_id = 0;

		//入力値チェック
		if (para1 != null && para1.length() != 0) {
			pg_id = Integer.parseInt(para1);
		}

		// リクエストスコープに保存
		request.setAttribute("pg_id", pg_id);

		//リクエストスコープに各ページ用情報保存、フォワード先を設定
		if (pg_id==1) {
			//トップページ
			forward = movetoTop(request);
		} else if (pg_id==2) {
			//お得情報一覧
			//forward = movetoConcept(request);
		} else if (pg_id==3) {
			//お得情報詳細
			//forward = movetoMenu(request);
		} else if (pg_id==4) {
			//徳島の名産品
			//forward = movetoLogin();
		} else if (pg_id==5) {
			//推し土産
			//forward = movetoConcept(request);
		} else if (pg_id==6) {
			//県西
			//forward = movetoMenu(request);
		} else if (pg_id==7) {
			//県東
			//forward = movetoLogin();
		} else if (pg_id==8) {
			//県南
			//forward = movetoConcept(request);
		} else if (pg_id==9) {
			//価格別一覧
			//forward = movetoMenu(request);
		} else if (pg_id==10) {
			//味別一覧
			//forward = movetoLogin();
		} else if (pg_id==11) {
			//数量別一覧
			//forward = movetoConcept(request);
		} else if (pg_id==12) {
			//渡す人別一覧
			//forward = movetoMenu(request);
		} else if (pg_id==13) {
			//カテゴリ（品目）別一覧
			//forward = movetoLogin();
		} else if (pg_id==14) {
			//試食レポート一覧
			//forward = movetoConcept(request);
		} else if (pg_id==15) {
			//試食レポート詳細
			//forward = movetoMenu(request);
		} else if (pg_id==16) {
			//各サブカテゴリ一覧
			//forward = movetoLogin();
		} else if (pg_id==17) {
			//お問い合わせ
			//forward = movetoConcept(request);
		} else if (pg_id==18) {
			//商品詳細
			//forward = movetoMenu(request);
		} else if (pg_id==19) {
			//価格別選択
			//forward = movetoLogin();
		} else if (pg_id==20) {
			//地域別選択
			//forward = movetoConcept(request);
		} else if (pg_id==21) {
			//味別選択
			//forward = movetoMenu(request);
		} else if (pg_id==22) {
			//数量別選択
			//forward = movetoLogin();
		} else if (pg_id==23) {
			//対象別選択
			//forward = movetoConcept(request);
		} else if (pg_id==24) {
			//カテゴリ別
			//forward = movetoMenu(request);
		} else if (pg_id==25) {
			//プライバシーポリシー
			//forward = movetoLogin();
		}


		else {
			//トップページ
			forward = movetoTop(request);
		}


		//メイン画面にフォーワード
		RequestDispatcher dispatcher = request.getRequestDispatcher(forward);
		dispatcher.forward(request, response);

	}

	/**
	 * フォワード前処理
	 */

	private String movetoTop(HttpServletRequest request) {
		// フォーワード先 "
		String forward = "WEB-INF/jsp/login_in.jsp";
		return forward;
	}




















	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
